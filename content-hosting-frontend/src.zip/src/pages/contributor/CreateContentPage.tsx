// src/pages/contributor/CreateContentPage.tsx
import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { ContentFormData } from '../../types';
import { ContentService } from '../../utils/mockData';
import ContentForm from '../../components/forms/ContentForm';
import { supabase } from '../../utils/supabaseClient';



const CreateContentPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { search } = useLocation();
  const params = new URLSearchParams(search);

  const onlyArticle = params.get('type') === 'article';
  const onlyPodcast = params.get('type') === 'podcast';
  const [loading, setLoading] = useState(false);

  // Only contributors can create
  if (!user || user.role !== 'contributor') {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">
              Access Denied
            </h1>
            <p className="text-gray-600">
              You need to be a contributor to create content.
            </p>
          </div>
        </div>
      </div>
    );
  }

//   const handleSubmit = async (formData: ContentFormData) => {
//   setLoading(true);
//   try {
//     // Simulate network/API delay
//     await new Promise<void>((resolve) => setTimeout(resolve, 500));

//     // Persist the new podcast
//     ContentService.createContent({
//       ...formData,
//       author_id: user.id,
//     });

//     // Redirect to the public podcasts list
//     navigate('/podcasts');
//   } catch (err) {
//     console.error('Error creating content:', err);
//     alert('Failed to create podcast. Please try again.');
//   } finally {
//     setLoading(false);
//   }
// };
const handleSubmit = async (formData: ContentFormData) => {
  setLoading(true);
  try {
    // 1) If this is a podcast, upload the file & get its URL + duration
    let audio_file_url: string | null = null;
    let audio_duration: number | null = null;

    if (formData.content_type === 'podcast' && formData.audio_file) {
      const file = formData.audio_file;
      const fileName = `${Date.now()}_${file.name}`;

      // Upload to the "podcasts" bucket
      const { data: uploadData, error: uploadError } = await supabase
        .storage
        .from('podcasts')
        .upload(fileName, file);
      if (uploadError) throw uploadError;

      // Get its public URL (no error field returned here)
      const { data } = supabase
        .storage
        .from('podcasts')
        .getPublicUrl(uploadData.path);
      audio_file_url = data.publicUrl;

      // Compute duration via an <audio> element
      const audio = new Audio(audio_file_url);
      await new Promise<void>((resolve) => {
        audio.onloadedmetadata = () => resolve();
      });
      audio_duration = Math.round(audio.duration);
    }

    // 2) Build the row payload
    const nowIso = new Date().toISOString();
    const isPublishing = formData.status === 'published';

    const payload = {
      title: formData.title,
      description: formData.description,
      content_type: formData.content_type,    // article or podcast
      status: formData.status,
      tags: formData.tags,
      author_id: user.id,
      published_at: isPublishing ? nowIso : null,
      rich_text_content:
        formData.content_type === 'article'
          ? formData.rich_text_content
          : null,
      audio_file_url,
      audio_duration,
    };

    // 3) Insert into Supabase
    const { error: insertError } = await supabase
      .from('content')
      .insert(payload);
    if (insertError) throw insertError;

    // 4) Redirect to the correct list
    navigate(
      formData.content_type === 'podcast' ? '/podcasts' : '/articles'
    );
  } catch (err: any) {
    console.error('Error saving content:', err);
    alert(err.message || 'Failed to save. Please try again.');
  } finally {
    setLoading(false);
  }
};


  const handleCancel = () => {
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-3xl font-bold text-gray-900">
            {onlyArticle
              ? 'Create Article'
              : onlyPodcast
              ? 'Create Podcast'
              : 'Create Content'}
          </h1>
          <button
            onClick={handleCancel}
            className="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
          >
            Cancel
          </button>
        </div>

        {/* Subheading */}
        <p className="text-gray-600 mb-8">
          {onlyArticle
            ? 'Draft your article below — no podcast fields will appear.'
            : onlyPodcast
            ? 'Upload your podcast audio below — no article fields will appear.'
            : 'Choose article or podcast, then fill in the details.'}
        </p>

        {/* Form */}
        <ContentForm
          onlyArticle={onlyArticle}
          onlyPodcast={onlyPodcast}
          onSubmit={handleSubmit}
          onCancel={handleCancel}
          loading={loading}
          isEditing={false}
        />
      </div>
    </div>
  );
};

export default CreateContentPage;
